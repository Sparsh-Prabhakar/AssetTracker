<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userIssues extends Model
{
    protected $table = 'userissues';
    public $primaryKey = 'id';
}
