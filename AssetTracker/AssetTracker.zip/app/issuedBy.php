<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class issuedBy extends Model
{
    protected $table = 'issuedby';
    public $primaryKey = 'id';
}
