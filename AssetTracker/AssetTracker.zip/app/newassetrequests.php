<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class newassetrequests extends Model
{
    protected $table = 'newassetrequests';
    public $primaryKey = 'id';
}
