<?php
    use App\asset;
    $ids=asset::get();
?>

<?php $__env->startSection('content'); ?>
            <div clas="form-group row">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>'">
    <style>
        *{
            text-decoration: none;
        }
        label{
            font-size: 20px;
        }
    </style>
    <div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
        <br><br>
        <h1>Report a Problem</h1>
        <form action="/home/issue/file" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-3">Name of Asset</label>
                <select name="filename" class="col-2">
                    <?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id->name); ?>"><?php echo e($id->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group row">
                <label clas="col-3">Issue</label>
                <textarea type="text" class="form-control col-2" name="fileissue"></textarea>
            </div>
            <div class="form-group row">
                <div class="col-4">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/file.blade.php ENDPATH**/ ?>