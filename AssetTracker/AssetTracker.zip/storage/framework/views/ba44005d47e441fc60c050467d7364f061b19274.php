<?php
    use App\User;
    use App\asset;
?>


<?php $__env->startSection('content'); ?>

<div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
    <h1 style="text-align: center"><strong>ORDERS</strong></h1>
    <br><br>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $username = User::where('id',$order->orderedBy)->get();
        $assetname = asset::where('id',$order->assetOrdered)->get();
    ?>
        <div class="card" style="width:40%">
            <div class="card-header" style="background-color: gray">
                <h3><?php echo e($username[0]['name']); ?></h3>
            </div>
            <div class="card-body">
                <form action="/home/ordersRecieved/done" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group" style="visibility:hidden">
                            <input class="form-control" type="text" name="id" value="<?php echo e($order->id); ?>" readonly style="text-align: center">
                        </div>
                    <div class="form-group">
                        <input class="form-control" type="text" name="asset" value="<?php echo e($assetname[0]['name']); ?>" readonly style="text-align: center">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="quantity" value="<?php echo e($order->quantityOrdered); ?>" readonly style="text-align:center">
                    </div>
                    <div class="form-group">
                        <div class="col-4">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success" name="submit">Recieved</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <br><br>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/ordersRecieved.blade.php ENDPATH**/ ?>