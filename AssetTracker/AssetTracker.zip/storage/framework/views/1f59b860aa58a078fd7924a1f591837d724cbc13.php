<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<style>
    *{
        text-decoration: none;
    }

    th{
        padding: 10px 75px;
        borer
    }
    td{
        text-align:center;
    }
</style>
<div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
    <h1><strong>System Assets</strong></h1>
    <br><br>
    <table class="table-bordered">
        <tr>
            <th>No.</th>
            <th>Asset</th>
            <th>Total Quantity</th>
            <th>Remaining Quantity</th>
        </tr>
        <?php $id = 1?>
        <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($id); ?></td>
            <td><?php echo e($asset->name); ?></td>
            <td><?php echo e($asset->totalQuantity); ?></td>
            <td><?php echo e($asset->remainingQuantity); ?></td>      
        </tr>
        <?php $id = $id + 1; ?>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br><br><br><br>        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/viewAvailableAssets.blade.php ENDPATH**/ ?>