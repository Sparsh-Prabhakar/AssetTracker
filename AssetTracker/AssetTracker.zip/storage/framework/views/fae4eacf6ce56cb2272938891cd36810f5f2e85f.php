<?php
    use App\asset;
?>



<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<style>
    h3,h5{
        text-align: center;
    }
</style>
<div class="container" align="center">
    <br><br>
    <h1>Assets Granted</h1>
    <br>
    <table class="table">
        <tr>
            <th>No.</th>
            <th>Asset</th>
            <th>Quantity</th>
        </tr>
        <?php $__currentLoopData = $grants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php
            $asset = asset::find($grant->itemIssued);
            // echo $asset;
            $id = 1;
        ?>
        <tr>
            <td><?php echo e($id); ?></td>
            <td><?php echo e($asset['name']); ?></td>
            <td ><?php echo e($grant->quantityIssued); ?></td>
        </tr>
        <?php
            $id = $id + 1;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/userGranted.blade.php ENDPATH**/ ?>