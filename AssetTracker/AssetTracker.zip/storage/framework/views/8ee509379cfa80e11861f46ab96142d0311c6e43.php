<?php
    use App\User;
    use App\issuedBy;
?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<style>
    .anchor{
        color : black;
    }
    .anchor:hover{
        text-decoration: none;
        color: black;
    }
</style>
<?php if(Auth::user()->role!=6): ?>
    <div class="row" style="margin-left:4%;margin-top:3%;width:75%">
        <div class="col-lg-4 col-md-6">
            <a href="/home/userrequests" class="anchor">
                <div class="card" style="height: 100%">
                    <div class="card-body">
                        <div class="stat-content">
                            <div class="text-left dib">
                                <div class="stat-text" style="font-size: 25px"><i class="fa fa-calendar-check-o" style="color: green"></i>  Assets Requested : <?php echo e(count($requests)); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-md-6">
            <a href="/home/usergranted" class="anchor">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-content">
                            <div class="text-left dib">
                                <div class="stat-text" style="font-size: 25px"><span class="count"><i class="fa fa-calendar-check-o" style="color:blueviolet"></i>  Assets Granted : <?php echo e(count($granted)); ?></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>      
    </div>
    <div class="container" style="background-color:white;width:80%;margin-left: 2%">
        <?php echo $__env->yieldContent('dashboard'); ?>
    </div>
    <?php else: ?>
    <h1>CONTACT ADMIN TO ASSIGN YOURSELF A ROLE.<br> You Wont be able to do anything before that.<br>Contact Email : adminofmysystem@gmail.com</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/Home.blade.php ENDPATH**/ ?>