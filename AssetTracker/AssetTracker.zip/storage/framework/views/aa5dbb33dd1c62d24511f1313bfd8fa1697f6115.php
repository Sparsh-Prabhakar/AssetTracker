<?php
    use App\asset;
    $ids=asset::get();  
?>


<?php $__env->startSection('content'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        *{
            text-decoration: none;
        }
        label{
            font-size: 20px;
        }
    </style>   
    <div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
        <h1 style="text-align: center"><strong>Issue an Asset</strong></h1>
        <br><br>
        <form action="/home/issue/store" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-3 col-lg-offset-3">Name of the Asset</label>
                <select name="assetDropdown" class="col-2">
                        <?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id->id); ?>"><?php echo e($id->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <br>
            <div class="form-group row">
                <label class="col-3 col-lg-offset-3">Quantity</label>
                <input type="number" class="form-control col-2" name="assetQuantity" max="50" placeholder="0">
            </div>
            <div class = "row">
                <div class = "col-4 col-lg-offset-7">
                    <div class = "form-group">
                        <button type="submit" class = "btn btn-primary" name="submit">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/issueAsset.blade.php ENDPATH**/ ?>