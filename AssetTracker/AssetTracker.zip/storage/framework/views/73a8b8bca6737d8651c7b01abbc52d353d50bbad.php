<?php
    use App\User;
    $users=User::get()->where('role','!=',6); 
?>


<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        *{
            text-decoration: none;
        }
        label{
            font-size: 20px;
        }
    </style>
    <div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
        <span class="border">
            <form action="/home/changedRole" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                        <label class="col-3">Name of the Users</label>
                        <select name="userDropdown" id="dropdown" class="col-2">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> : <?php echo e($user->role); ?> 
                          
                        </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <br>
                    <div class="form-group row">
                        if
                        <label class="col-3">Role</label>
                        <select name="roleDropdown" class="col-2">
                                <option value="0">0: System Admin</option>
                                <option value="1">1: Student</option>
                                <option value="2">2: Lab Assitant</option>
                                <option value="2">2: Peon</option>
                                <option value="3">3: Teacher</option>
                                <option value="4">4: Deputy HOD</option>
                                <option value="4">4: HOD</option>
                                <option value="5">5: Purchase Officer</option>
                        </select>
                    </div>
                    <div class = "row col-4 form-group">
                                <button type="submit" class = "btn btn-primary" name="submit">Submit</button>
                    </div>
            </form>
        </span>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/changeRole.blade.php ENDPATH**/ ?>