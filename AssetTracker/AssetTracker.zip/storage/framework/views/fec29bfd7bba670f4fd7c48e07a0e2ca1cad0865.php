<?php
    use App\asset;
    $ids=asset::get();
?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<style>
    *{
        text-decoration: none;
    }
    label{
        font-size: 20px;
    }
</style>    
    <div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
        <h1><strong>Request for Unavailable Asset</strong></h1>
        <br><br>
        <form action="/home/requestnewasset/newasset" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-3 col-lg-offset-3">Name of Asset</label>
                <input type="text" class="form-control col-lg-2" name="newassetname">
            </div>
            <div class="form-group row">
                    <label class="col-3 col-lg-offset-3">Description of an Asset</label>
                    <textarea type="text" class="form-control col-lg-2" name="newdescription" ></textarea>
            </div>
            <div class="form-group row">
                    <label class="col-3 col-lg-offset-3">Quantity of an Asset</label>
                    <input type="number" class="form-control col-lg-2" name="newquantity">
            </div>
            <div class="form-group row">
                    <div class="col-lg-4 col-lg-offset-7">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                        </div>
                    </div>
                </div>
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/requestNewAssets.blade.php ENDPATH**/ ?>