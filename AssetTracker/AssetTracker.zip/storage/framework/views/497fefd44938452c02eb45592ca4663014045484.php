<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<style>
    *{
        text-decoration: none;
    }
    label{
        font-size: 20px;
    }
</style>
<div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
    <h1 style="text-align: center"><strong>Edit Profile</strong></h1>
    <br>
    <form action="/home/edit/update" method="POST" autocomplete="off">
        <?php echo csrf_field(); ?>
        <br>
        <div class="form-group row">
            <label class="col-3 col-lg-offset-3">E-mail Address</label>
            <input type="email" class="form-control col-2" name="email" value="<?php echo e(Auth::user()->email); ?>" readonly>
        </div>
        <div class="form-group row">
            <label class="col-3 col-lg-offset-3">Current Password</label>
            <input type="password" class="form-control col-2" name="currentpassword">
        </div>
        <div class="form-group row">
            <label class="col-3 col-lg-offset-3">New Password</label>
            <input type="password" class="form-control col-2" name="newpassword">
        </div>
        <div class = "row">
            <div class = "col-4 col-lg-offset-7">
                <div class = "form-group">
                    <button type="submit" class = "btn btn-primary" name="submit">Submit</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/edit.blade.php ENDPATH**/ ?>