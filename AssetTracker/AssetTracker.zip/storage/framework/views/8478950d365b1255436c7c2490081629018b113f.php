<?php
    Use App\asset;
    Use App\User;
?>



<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<style>
    *{
        text-decoration: none;
    }
    label{
        font-size: 20px;
    }

    .btn{
        margin-right: 2%;
    }
</style>
<div style="width:inherit;height:inherit;vertical-align:middle" align="center">
    <br><br><br><br>
    <h1 style="text-align: center"><strong>Return Assets</strong></h1>
    <br><br>
        <?php $__currentLoopData = $return; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php //echo var_dump($id);?>
            
            <?php
                $itemId = $id->itemIssued;
                "<br>";
                $assetname = asset::where('id',$itemId)->get();
                //echo($assetname);
                $username = User::where('id',$id->userId)->get();
                //echo($username);
                // dd ($assetname);
            ?>
            <div class="card" style="width:40%">
                <form action="/home/requests/returned" method="POST">
                <div class="card-header" style="background-color: gray">
                    <h3><input type="text" name="name" value="<?php echo e($username[0]['name']); ?>" readonly style="text-align: center;background-color: gray;border:none"></h3>
                </div>
                
                    <div class="card-body">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                    <input class="form-control" type="text" name="id" value="<?php echo e($id->id); ?>" readonly style="text-align: center">
                                </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="asset" value="<?php echo e($assetname[0]['name']); ?>" readonly style="text-align: center">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="quantity" value="<?php echo e($id->quantityIssued); ?>" readonly style="text-align:center">
                            </div>
                            <div class="form-group">
                                <div class="col-4">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-danger col-11" name="submit">Asset Returned</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                
            </div>
            <br><br>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/return.blade.php ENDPATH**/ ?>