<?php
    use App\User;
?>

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app/css')); ?>">
    <div style="width:inherit;height:inherit;vertical-align:middle;" align="center">
            <h1 style="text-align: center"><strong>New Asset Requests</strong></h1>
            <br><br>
            <?php $__currentLoopData = $newassetrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $user = User::where('id',$new->userId)->get();
                    // echo $user;
                ?>
                <div class="card" style="width:40%">
                    <div class="card-header" style="background-color: gray">
                        <h3><?php echo e($user[0]['name']); ?></h3>
                    </div>
                    <div class="card-body">
                            <form action="/home/newassetrequests/approve" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input class="form-control" type="text" name="asset" value="<?php echo e($new->assetOrdered); ?>" readonly style="text-align: center">
                                </div>
                                <div class="form-group">
                                        <input type="text" class="form-control" name="quantity" value="<?php echo e($new->quantity); ?>" readonly style="text-align:center">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="reason" value="<?php echo e($new->reason); ?>" readonly style="text-align:center">
                                </div>
                                <div class="form-group">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-success" name="submit">Approve this asset</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>   
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AssetTracker\AssetTracker\resources\views/dashboard/newassetrequests.blade.php ENDPATH**/ ?>